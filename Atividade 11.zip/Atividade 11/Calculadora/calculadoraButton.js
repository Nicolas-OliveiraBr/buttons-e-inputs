function soma() {
    let soma = document.querySelector('div')
    let number1 = document.querySelector('#number1')
    let number2 = document.querySelector('#number2')
    soma.insertAdjacentHTML('beforeend', `<h3>A operação realizada foi soma e o resultado é ${number1.value*1 + number2.value*1}.</h3>`)
}

function subt() {
    let subt = document.querySelector('div')
    let number1 = document.querySelector('#number1')
    let number2 = document.querySelector('#number2')
    subt.insertAdjacentHTML('beforeend', `<h3>A operação realizada foi subtração e o resultado é ${number1.value - number2.value}.</h3>`)
}

function mult() {
    let mult = document.querySelector('div')
    let number1 = document.querySelector('#number1')
    let number2 = document.querySelector('#number2')
    mult.insertAdjacentHTML('beforeend', `<h3>A operação realizada foi multiplicação e o resultado é ${number1.value * number2.value}.</h3>`)
}

function divid() {
    let divid = document.querySelector('div')
    let number1 = document.querySelector('#number1')
    let number2 = document.querySelector('#number2')
    divid.insertAdjacentHTML('beforeend', `<h3>A operação realizada foi divisão e o resultado é ${number1.value / number2.value}.</h3>`)
}