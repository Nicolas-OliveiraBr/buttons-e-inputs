function showMessage() {
    let newDiv = document.querySelector('main')
    newDiv.insertAdjacentHTML('beforeend', '<div class="nameAge"></div>')

    let input1 = document.querySelector('#nome')
    let input2 = document.querySelector('#idade')
   
    let h1 = document.querySelector('.nameAge')
    h1.insertAdjacentHTML('beforeend', `<h1>Seja Bem Vindo, ${input1.value}! Você possui ${input2.value} anos!</h1> <p>Obrigado por Participar!</p>`);


}